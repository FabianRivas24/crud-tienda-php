<?php
require_once 'includes/conexion.php';
require_once 'includes/funciones_usuario.php';
require_once 'includes/funciones_producto.php';
require_once 'includes/funciones_carrito.php';

if (!usuarioLogueado()) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['agregar'])) {
        $productoId = $_POST['producto_id'];
        $cantidad = $_POST['cantidad'];
        agregarAlCarrito($productoId, $cantidad);
    } elseif (isset($_POST['eliminar'])) {
        $productoId = $_POST['producto_id'];
        eliminarDelCarrito($productoId);
    } elseif (isset($_POST['vaciar'])) {
        vaciarCarrito();
    } elseif (isset($_POST['comprar'])) {
        vaciarCarrito();
        $mensaje = "¡Compra realizada con éxito!";
    }
}

$carrito = obtenerCarrito();
$total = calcularTotal($carrito, $pdo);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <div class="container">
            <h1>Tienda Online</h1>
            <nav class="nav">
                <a href="productos.php" class="btn btn-sm">Productos</a>
                <a href="carrito.php" class="btn btn-sm">Carrito</a>
                <a href="logout.php" class="btn btn-sm btn-danger">Cerrar Sesión</a>
            </nav>
        </div>
    </div>

    <div class="container">
        <h2>Tu Carrito de Compras</h2>
        
        <?php if (isset($mensaje)): ?>
            <div class="alert alert-success"><?= $mensaje ?></div>
        <?php endif; ?>
        
        <?php if (empty($carrito)): ?>
            <div class="alert alert-error">Tu carrito está vacío</div>
            <a href="productos.php" class="btn">Ir a Productos</a>
        <?php else: ?>
            <div class="cart-container">
                <div class="cart-items">
                    <?php foreach ($carrito as $productoId => $cantidad): 
                        $producto = obtenerProducto($productoId, $pdo);
                        if ($producto): ?>
                            <div class="cart-item">
                                <div class="cart-item-image">
                                    <img src="<?= htmlspecialchars($producto['imagen']) ?>" alt="<?= htmlspecialchars($producto['nombre']) ?>">
                                </div>
                                <div class="cart-item-info">
                                    <h3 class="cart-item-title"><?= htmlspecialchars($producto['nombre']) ?></h3>
                                    <p class="cart-item-price">$<?= number_format($producto['precio'], 2) ?> c/u</p>
                                    
                                    <form method="POST" class="cart-item-controls">
                                        <input type="hidden" name="producto_id" value="<?= $productoId ?>">
                                        <label>
                                            Cantidad:
                                            <input type="number" name="cantidad" value="<?= $cantidad ?>" min="1" class="quantity-input">
                                        </label>
                                        <button type="submit" class="btn btn-sm">Actualizar</button>
                                    </form>
                                </div>
                                <div class="cart-item-subtotal">
                                    <p>$<?= number_format($producto['precio'] * $cantidad, 2) ?></p>
                                    <form method="POST">
                                        <input type="hidden" name="producto_id" value="<?= $productoId ?>">
                                        <button type="submit" name="eliminar" class="btn btn-sm btn-danger">Eliminar</button>
                                    </form>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
                
                <div class="cart-total">
                    <h3>Total: $<?= number_format($total, 2) ?></h3>
                </div>
                
                <div class="cart-actions">
                    <form method="POST">
                        <button type="submit" name="vaciar" class="btn btn-danger">Vaciar Carrito</button>
                        <button type="submit" name="comprar" class="btn btn-success">Finalizar Compra</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
