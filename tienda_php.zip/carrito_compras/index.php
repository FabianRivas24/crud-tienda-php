<?php
// Redirigir directamente al login
header("Location: login.php");
exit();
?>