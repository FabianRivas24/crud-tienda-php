<?php
require_once '../includes/conexion.php';
require_once '../includes/funciones_usuario.php';
require_once '../includes/funciones_producto.php';

if (!usuarioLogueado()) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$exito = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $precio = $_POST['precio'];
    $descripcion = $_POST['descripcion'];
    
    // Procesar imagen
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $extension = pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION);
        $nombreArchivo = uniqid() . '.' . $extension;
        $rutaDestino = $uploadDir . $nombreArchivo;
        
        if (move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino)) {
            if (agregarProducto($nombre, $precio, $descripcion, 'uploads/' . $nombreArchivo, $pdo)) {
                $exito = "Producto agregado correctamente";
            } else {
                $error = "Error al agregar el producto";
            }
        } else {
            $error = "Error al subir la imagen";
        }
    } else {
        $error = "Debes seleccionar una imagen válida";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Producto</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <div class="header">
        <div class="container">
            <h1>Tienda Online</h1>
            <nav class="nav">
                <a href="../productos.php" class="btn btn-sm">Productos</a>
                <a href="../carrito.php" class="btn btn-sm">Carrito</a>
                <a href="../logout.php" class="btn btn-sm btn-danger">Cerrar Sesión</a>
            </nav>
        </div>
    </div>

    <div class="container">
        <div class="form-container">
            <h2>Agregar Nuevo Producto</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($exito): ?>
                <div class="alert alert-success"><?= $exito ?></div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="nombre">Nombre del Producto</label>
                    <input type="text" id="nombre" name="nombre" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="precio">Precio</label>
                    <input type="number" id="precio" name="precio" step="0.01" min="0" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="descripcion">Descripción</label>
                    <textarea id="descripcion" name="descripcion" class="form-control" required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="imagen">Imagen del Producto</label>
                    <input type="file" id="imagen" name="imagen" accept="image/*" class="form-control" required>
                </div>
                
                <button type="submit" class="btn">Agregar Producto</button>
                <a href="../productos.php" class="btn btn-danger">Cancelar</a>
            </form>
        </div>
    </div>
</body>
</html>
