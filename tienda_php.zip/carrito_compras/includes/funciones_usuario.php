<?php
session_start();

function registrarUsuario($nombre, $email, $contraseña, $pdo) {
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->rowCount() > 0) {
        return false;
    }
    
    $contraseñaHash = password_hash($contraseña, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, email, contraseña) VALUES (?, ?, ?)");
    return $stmt->execute([$nombre, $email, $contraseñaHash]);
}

function iniciarSesion($email, $contraseña, $pdo) {
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario && password_verify($contraseña, $usuario['contraseña'])) {
        $_SESSION['usuario'] = [
            'id' => $usuario['id'],
            'nombre' => $usuario['nombre'],
            'email' => $usuario['email']
        ];
        return true;
    }
    return false;
}

function usuarioLogueado() {
    return isset($_SESSION['usuario']);
}

function cerrarSesion() {
    session_unset();
    session_destroy();
}
?>

