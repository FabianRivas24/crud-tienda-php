<?php
function agregarAlCarrito($productoId, $cantidad = 1) {
    if (!isset($_SESSION['carrito'])) {
        $_SESSION['carrito'] = [];
    }

    if (isset($_SESSION['carrito'][$productoId])) {
        $_SESSION['carrito'][$productoId] += $cantidad;
    } else {
        $_SESSION['carrito'][$productoId] = $cantidad;
    }
}

function obtenerCarrito() {
    return $_SESSION['carrito'] ?? [];
}

function eliminarDelCarrito($productoId) {
    if (isset($_SESSION['carrito'][$productoId])) {
        unset($_SESSION['carrito'][$productoId]);
    }
}

function calcularTotal($carrito, $pdo) {
    $total = 0;
    foreach ($carrito as $productoId => $cantidad) {
        $producto = obtenerProducto($productoId, $pdo);
        if ($producto) {
            $total += $producto['precio'] * $cantidad;
        }
    }
    return $total;
}

function vaciarCarrito() {
    unset($_SESSION['carrito']);
}
?>
