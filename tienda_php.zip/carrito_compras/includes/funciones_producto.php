<?php
function obtenerProductos($pdo) {
    $stmt = $pdo->query("SELECT * FROM productos");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function agregarProducto($nombre, $precio, $descripcion, $imagen, $pdo) {
    $stmt = $pdo->prepare("INSERT INTO productos (nombre, precio, descripcion, imagen) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$nombre, $precio, $descripcion, $imagen]);
}

function obtenerProducto($id, $pdo) {
    $stmt = $pdo->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
