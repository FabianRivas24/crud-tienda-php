<?php
require_once 'includes/conexion.php';
require_once 'includes/funciones_usuario.php';
require_once 'includes/funciones_producto.php';
require_once 'includes/funciones_carrito.php';

if (!usuarioLogueado()) {
    header('Location: login.php');
    exit();
}

$productos = obtenerProductos($pdo);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Productos</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <div class="container">
            <h1>Tienda Online</h1>
            <nav class="nav">
                <a href="productos.php" class="btn btn-sm">Inicio</a>
                <a href="carrito.php" class="btn btn-sm">Ver Carrito</a>
                <a href="admin/agregar_producto.php" class="btn btn-sm">Agregar Producto</a>
                <a href="logout.php" class="btn btn-sm btn-danger">Cerrar Sesión</a>
            </nav>
        </div>
    </div>

    <div class="container">
        <h2>Productos Disponibles</h2>
        
        <div class="products-grid">
            <?php foreach ($productos as $producto): ?>
                <div class="product-card">
                    <div class="product-image">
                        <img src="<?= htmlspecialchars($producto['imagen']) ?>" alt="<?= htmlspecialchars($producto['nombre']) ?>">
                    </div>
                    <div class="product-info">
                        <h3 class="product-title"><?= htmlspecialchars($producto['nombre']) ?></h3>
                        <p class="product-price">$<?= number_format($producto['precio'], 2) ?></p>
                        <p class="product-description"><?= htmlspecialchars($producto['descripcion']) ?></p>
                        
                        <form action="carrito.php" method="POST" class="form-inline">
                            <input type="hidden" name="producto_id" value="<?= $producto['id'] ?>">
                            <label>
                                Cantidad:
                                <input type="number" name="cantidad" value="1" min="1" class="quantity-input">
                            </label>
                            <button type="submit" name="agregar" class="btn btn-sm">Agregar</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
