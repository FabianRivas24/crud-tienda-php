<?php
require_once 'includes/funciones_usuario.php';
cerrarSesion();
header('Location: login.php');
exit();
?>
